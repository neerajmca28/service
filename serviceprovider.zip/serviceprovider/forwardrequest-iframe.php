<div style="text-align:center">
<iframe src='forward_service_request.php?id=<?= $_GET["id"]?>&req_id=<?=$_GET["req_id"]?>' height="220" width="480" frameborder="0" scrolling="no"></iframe>
</div>